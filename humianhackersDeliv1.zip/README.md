humianhackers
=============
Running main.py will run the following in order:

ReadDataSet.py
SplitText.py
EntityDet.py

At the moment the testing is done using only the first 100 lines of the data in order to cut down on runtime.